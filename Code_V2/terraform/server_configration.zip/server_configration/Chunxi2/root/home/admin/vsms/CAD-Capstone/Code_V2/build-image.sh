#!/bin/bash

# 1. Standard PATH for cron
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

# 2. Define explicit paths
# Note: Your .git is in /home/admin/vsms/CAD-Capstone/
GIT_DIR="/home/admin/vsms/CAD-Capstone/.git"
WORK_TREE="/home/admin/vsms/CAD-Capstone"
SUB_DIR="/home/admin/vsms/CAD-Capstone/Code_V2"

# Navigate to the code directory
cd "$SUB_DIR" || exit 1

# 3. Get Remote Hash (Directly from URL to be safe)
REMOTE=$(git ls-remote https://github.com/czhang1818/CAD-Capstone.git refs/heads/main | awk '{print $1}')

# 4. Get Local Hash (Explicitly pointing to the parent .git folder)
LOCAL=$(git --git-dir="$GIT_DIR" --work-tree="$WORK_TREE" rev-parse HEAD)

# 5. Safety Check
if [ -z "$REMOTE" ] || [ -z "$LOCAL" ]; then
    echo "$(date): Error - Could not resolve hashes. Remote: [$REMOTE], Local: [$LOCAL]"
    exit 1
fi

# 6. Comparison Logic
if [ "$LOCAL" != "$REMOTE" ]; then
    echo "$(date): New update found. Local: $LOCAL, Remote: $REMOTE. Deploying..."
    
    # Pull updates
    git --git-dir="$GIT_DIR" --work-tree="$WORK_TREE" pull origin main
    
    # Run Podman (already in SUB_DIR)
    podman compose -f podman-compose.web.yml build
    podman compose -f podman-compose.api.yml build
    podman tag localhost/vsms-web:latest 10.16.1.11:5000/vsms-web:latest
    podman tag localhost/vsms-api:latest 10.16.1.11:5000/vsms-api:latest
    podman push --tls-verify=false 10.16.1.11:5000/vsms-web:latest
    podman push --tls-verify=false 10.16.1.11:5000/vsms-api:latest

    # Cleanup
    podman images --filter "dangling=true" -q | xargs -r podman rmi
    podman builder prune -a -f
else
    echo "$(date): System up to date. Local: $LOCAL"
fi

