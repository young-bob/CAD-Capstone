echo boyang_1
ping -c 2 10.18.1.226 | grep 'from'
echo boyang_2
ping -c 2 10.18.1.207 | grep 'from'
echo chunxi_1
ping -c 2 10.16.1.140 | grep 'from'
echo chunxi_2
ping -c 2 10.16.1.11 | grep 'from'
echo brad_1
ping -c 2 10.17.1.32 | grep 'from'
echo brad_2
ping -c 2 10.17.1.224 | grep 'from'
echo marieth_1
ping -c 2 10.19.1.243 | grep 'from'
echo marieth_2
ping -c 2 10.19.1.25 | grep 'from'
