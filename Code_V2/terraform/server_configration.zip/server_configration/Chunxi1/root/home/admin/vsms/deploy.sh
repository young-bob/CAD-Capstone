#!/bin/bash

# --- Configuration ---
IMAGE_URL="10.16.1.11:5000/vsms-web:latest"


# 1. Get the Local Digest
# We use --format to get just the SHA256 string
LOCAL_DIGEST=$(podman image inspect "$IMAGE_URL" --format '{{.Digest}}' 2>/dev/null)

# 2. Get the Remote Digest (using skopeo)
# --tls-verify=false is often needed for internal HTTP registries
REMOTE_DIGEST=$(skopeo inspect --tls-verify=false docker://"$IMAGE_URL" | jq -r '.Digest')

# 3. Compare and Act
if [ "$LOCAL_DIGEST" == "$REMOTE_DIGEST" ]; then
    echo "Check Passed: Local image is up to date."
else
    echo "Change Detected! Updating image..."
    
    # Pull the new version
    podman pull --tls-verify=false "$IMAGE_URL"
    cd /home/admin/vsms/
    podman compose -f podman-compose.web.yml down
    podman compose -f podman-compose.web.yml up -d

    # Cleanup
    podman images --filter "dangling=true" -q | xargs -r podman rmi
    podman builder prune -a -f
    
    echo "Update complete."
fi
